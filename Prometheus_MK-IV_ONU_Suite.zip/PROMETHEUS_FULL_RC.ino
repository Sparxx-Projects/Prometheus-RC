�L#include "BluetoothSerial.h"
#include <ESP32Servo.h>

BluetoothSerial SerialBT;
Servo ServoArm;      // Servo Brazo (Hombro)
Servo ServoSteering; // Servo Dirección
Servo ServoGripper;  // Servo Pinza (Garra)

// === PINOUT ESP32 DEVKIT ===
const int ledConexion = 2;
const int buzzerPin = 15;
const int servoSteeringPin = 16;
const int servoArmPin = 27;
const int servoGripperPin = 17;

// Motor A (Izquierda - Trio 18, 19, 5)
const int motorA_ENA = 5;
const int motorA_IN1 = 18;
const int motorA_IN2 = 19;

// Motor B (Derecha - Trio 33, 32, 25)
const int motorB_ENB = 25;
const int motorB_IN3 = 33;
const int motorB_IN4 = 32;

// === VARIABLES DE CONTROL ===
const int MOTOR_MIN_PWM = 350;   // Umbral de arranque base
const int MOTOR_BACK_KICK = 550; // Aumentado para vencer estática en retroceso
float speedBalance = 1.0;
int anguloSteeringCenter = 91;
int anguloSteeringLeft = 45;
int anguloSteeringRight = 175;

int anguloGripperOpen = 180;
int anguloGripperClosed = 0;
int posArm = 90;

bool conectado = false;
unsigned long lastBlink = 0;
bool ledState = false;

// Estados de movimiento
bool moveForward = false;
bool moveBackward = false;
int currentSpeed = 255;
int targetSteeringAngle = 91;

// Lógica de Brazo Directo
bool girandoArr = false;
bool girandoAbj = false;
bool tankAssistActive = false; // Diferencial desactivado por defecto
unsigned long lastArmMove = 0;
unsigned long lastCommandTime = 0;

void stopAll() {
  moveForward = false;
  moveBackward = false;
  girandoArr = false;
  girandoAbj = false;

  // RESET DE SERVOS (Posiciones Neutras)
  targetSteeringAngle = anguloSteeringCenter;
  ServoSteering.write(anguloSteeringCenter);

  posArm = 90;
  ServoArm.write(posArm);

  ServoGripper.write(anguloGripperOpen);

  // Parada de motores
  analogWrite(motorA_ENA, 0);
  analogWrite(motorB_ENB, 0);
  digitalWrite(motorA_IN1, LOW);
  digitalWrite(motorA_IN2, LOW);
  digitalWrite(motorB_IN3, LOW);
  digitalWrite(motorB_IN4, LOW);
}

void setup() {
  Serial.begin(115200);
  SerialBT.begin("PROMETHEUS_RC");

  pinMode(ledConexion, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  pinMode(motorA_ENA, OUTPUT);
  pinMode(motorA_IN1, OUTPUT);
  pinMode(motorA_IN2, OUTPUT);
  pinMode(motorB_ENB, OUTPUT);
  pinMode(motorB_IN3, OUTPUT);
  pinMode(motorB_IN4, OUTPUT);

  ServoSteering.setPeriodHertz(50);
  ServoSteering.attach(servoSteeringPin, 500, 2400);
  ServoSteering.write(anguloSteeringCenter);

  ServoArm.setPeriodHertz(50);
  ServoArm.attach(servoArmPin, 500, 2400);
  ServoArm.write(posArm);

  ServoGripper.setPeriodHertz(50);
  ServoGripper.attach(servoGripperPin, 500, 2400);
  ServoGripper.write(anguloGripperOpen);

  // OPTIMIZACIÓN DE POTENCIA: Resolución de 10 bits para control gradual total
  analogWriteResolution(motorA_ENA, 10);
  analogWriteResolution(motorB_ENB, 10);
  analogWriteFrequency(motorA_ENA, 1000);
  analogWriteFrequency(motorB_ENB, 1000);
  SerialBT.setTimeout(20);
}

void processCommand(char c) {
  c = toupper(c);
  int value = -1;
  lastCommandTime = millis();

  if (SerialBT.available() > 0) {
    char next = SerialBT.peek();
    if (next >= '0' && next <= '9')
      value = SerialBT.parseInt();
  }

  // --- MOTORES ---
  if (c == 'F') {
    moveForward = true;
    moveBackward = false;
    if (value != -1)
      currentSpeed = constrain(value, 0, 255);
    Serial.print("MOTORES - Adelante: ");
    Serial.println(currentSpeed);
  } else if (c == 'B') {
    moveBackward = true;
    moveForward = false;
    if (value != -1)
      currentSpeed = constrain(value, 0, 255);
    Serial.print("MOTORES - Atras: ");
    Serial.println(currentSpeed);
  } else if (c == 'S') {
    moveForward = false;
    moveBackward = false;
    Serial.println("MOTORES - STOP");
  }

  // --- DIRECCIÓN VECTORIAL (Proporcional PRO) ---
  else if (c == 'V') {
    if (value != -1) {
      // PRO TIP: Recibir el ángulo final calculado por la App (45-175)
      targetSteeringAngle =
          constrain(value, anguloSteeringLeft, anguloSteeringRight);
      ServoSteering.write(targetSteeringAngle);
    }
  } else if (c == 'L' || c == 'R') {
    if (value != -1) {
      // Mapeo flexible para botones o sliders (0-100 de intensidad)
      int intensity = constrain(value, 0, 180);
      if (c == 'L')
        targetSteeringAngle =
            map(intensity, 0, 90, anguloSteeringCenter, anguloSteeringLeft);
      else
        targetSteeringAngle =
            map(intensity, 0, 90, anguloSteeringCenter, anguloSteeringRight);
    } else {
      targetSteeringAngle =
          (c == 'L') ? anguloSteeringLeft : anguloSteeringRight;
    }
    ServoSteering.write(targetSteeringAngle);
  } else if (c == 'N') {
    targetSteeringAngle = anguloSteeringCenter;
    ServoSteering.write(targetSteeringAngle);
  }

  // --- CONFIGURACIÓN ---
  else if (c == 'T') {
    tankAssistActive = !tankAssistActive;
    tone(buzzerPin, tankAssistActive ? 1500 : 600, 100);
  }

  // --- BRAZO ---
  else if (c == 'U') {
    girandoArr = true;
    girandoAbj = false;
  } else if (c == 'D') {
    girandoAbj = true;
    girandoArr = false;
  } else if (c == 'P') {
    girandoArr = false;
    girandoAbj = false;
  }

  // --- GARRA ---
  else if (c == 'O') {
    ServoGripper.write(anguloGripperOpen);
  } else if (c == 'C') {
    ServoGripper.write(anguloGripperClosed);
  } else if (c == 'G') {
    static bool open = true;
    open = !open;
    ServoGripper.write(open ? anguloGripperOpen : anguloGripperClosed);
  } else if (c == 'X') {
    stopAll();
  }
}

void loop() {
  bool hasClient = SerialBT.hasClient();

  // Gestión de Conexión y Seguridad
  if (hasClient && !conectado) {
    conectado = true;
    tone(buzzerPin, 1000, 200);
    lastCommandTime = millis();
  }

  if (!hasClient && conectado) {
    conectado = false;
    stopAll();
    digitalWrite(ledConexion, LOW);
  }

  if (conectado) {
    // Timeout de Seguridad: Si hay cliente pero no llegan comandos en 5s
    if (millis() - lastCommandTime > 5000) {
      moveForward = false;
      moveBackward = false;
      girandoArr = false;
      girandoAbj = false;
    }

    if (millis() - lastBlink > 500) {
      ledState = !ledState;
      digitalWrite(ledConexion, ledState);
      lastBlink = millis();
    }

    // Procesar comandos BT
    while (SerialBT.available()) {
      processCommand(SerialBT.read());
    }

    // --- LÓGICA DE MOTORES CON DIFERENCIAL ELECTRÓNICO ---
    // Añadimos zona muerta: si la velocidad es muy baja, forzamos STOP
    if (currentSpeed < 20) {
      moveForward = false;
      moveBackward = false;
    }

    if (moveForward || moveBackward) {
      // EXPERIMENTACIÓN: Llegar al máximo de potencia al 85% del joystick
      // (v=220)
      int minPower = moveBackward ? MOTOR_BACK_KICK : MOTOR_MIN_PWM;
      int baseSpeed = map(currentSpeed, 0, 220, minPower, 1023);
      baseSpeed = constrain(baseSpeed, 0, 1023);

      int speedA = baseSpeed;
      int speedB = baseSpeed;

      if (tankAssistActive && baseSpeed > 0) {
        // NORMALIZACIÓN: Usar un rango de 45 grados simétrico para el diferencial
        int offset = abs(targetSteeringAngle - anguloSteeringCenter);
        if (offset > 15) { // Deadzone de 15 grados
          // Calculamos factor (1.0 a 0.6) basado en un desplazamiento de 45 grados
          float factor = map(constrain(offset, 15, 45), 15, 45, 100, 60) / 100.0;
          
          if (targetSteeringAngle < anguloSteeringCenter) {
            speedA = (int)(baseSpeed * factor); // Giro Izquierda -> Frena Rueda A
          } else {
            speedB = (int)(baseSpeed * factor); // Giro Derecha -> Frena Rueda B
          }
        }
      }

      // Aplicar potencia en escala 10-bits (0-1023)
      if (currentSpeed >= 253) {
        // MODO NITRO: Bypass digital puro para máxima conexión eléctrica
        digitalWrite(motorA_ENA, HIGH);
        digitalWrite(motorB_ENB, HIGH);
      } else {
        analogWrite(motorA_ENA, (int)constrain(speedA * speedBalance, 0, 1023));
        analogWrite(motorB_ENB, speedB);
      }

      if (moveForward) {
        // Adelante (Re-ajustado): A(L,H) y B(H,L)
        digitalWrite(motorA_IN1, LOW);
        digitalWrite(motorA_IN2, HIGH);
        digitalWrite(motorB_IN3, HIGH);
        digitalWrite(motorB_IN4, LOW);
      } else {
        // Atrás: A(H,L) y B(L,H)
        digitalWrite(motorA_IN1, HIGH);
        digitalWrite(motorA_IN2, LOW);
        digitalWrite(motorB_IN3, LOW);
        digitalWrite(motorB_IN4, HIGH);
      }
    } else {
      digitalWrite(motorA_ENA, LOW);
      digitalWrite(motorB_ENB, LOW);
      // Aseguramos que los pines de dirección estén en LOW para no consumir
      digitalWrite(motorA_IN1, LOW);
      digitalWrite(motorA_IN2, LOW);
      digitalWrite(motorB_IN3, LOW);
      digitalWrite(motorB_IN4, LOW);
    }

    // --- MOVIMIENTO CONTINUO DE BRAZO (Más rápido: 2 deg / 8ms) ---
    if (millis() - lastArmMove > 8) {
      if (girandoArr) {
        posArm = constrain(posArm + 2, 0, 180);
        ServoArm.write(posArm);
      } else if (girandoAbj) {
        posArm = constrain(posArm - 2, 0, 180);
        ServoArm.write(posArm);
      }
      lastArmMove = millis();
    }
  } else {
    // Forzamos posición neutra repetidamente por seguridad si no hay conexión
    static unsigned long lastSafetyReset = 0;
    if (millis() - lastSafetyReset > 500) {
      ServoSteering.write(anguloSteeringCenter);
      ServoArm.write(90);
      lastSafetyReset = millis();
    }
  }
}
�L*cascade082�file:///C:/Users/etpal/Movistar%20Cloud/Documentos/Trabajos%20de%20clase%202025-2026/Programaci%C3%B3n/Prometheus/Arduino%20Programa/PROMETHEUS_FULL_RC/PROMETHEUS_FULL_RC.ino