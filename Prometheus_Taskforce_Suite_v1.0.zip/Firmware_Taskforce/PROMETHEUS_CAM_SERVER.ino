#include "esp_camera.h"
#include <WiFi.h>
#include "esp_http_server.h"

// ==========================================
// CONFIGURACIÓN HARDWARE: AI-THINKER ESP32-CAM
// ==========================================
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27

#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

#define FLASH_LED_PIN      4

// ==========================================
// CREDENCIALES Y RED PROMETHEUS
// ==========================================
const char* ssid = "Prometheus - Wifi";
const char* password = "Prometheus";

IPAddress local_IP(192, 168, 4, 1);
IPAddress gateway(192, 168, 4, 1);
IPAddress subnet(255, 255, 255, 0);

#define PART_BOUNDARY "123456789000000000000987654321"
static const char* _STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char* _STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char* _STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

httpd_handle_t stream_httpd = NULL;
httpd_handle_t stream_httpd_81 = NULL;

#include <lwip/sockets.h>

static esp_err_t stream_handler(httpd_req_t *req) {
    camera_fb_t * fb = NULL;
    esp_err_t res = ESP_OK;
    size_t _jpg_buf_len = 0;
    uint8_t * _jpg_buf = NULL;
    char part_buf[64];

    int sockfd = httpd_req_to_sockfd(req);
    int nodelay = 1;
    setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, &nodelay, sizeof(nodelay));

    res = httpd_resp_set_type(req, _STREAM_CONTENT_TYPE);
    if(res != ESP_OK){
        return res;
    }
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

    while(true){
        fb = esp_camera_fb_get();
        if (!fb) {
            Serial.println("[CAM] Error al capturar frame");
            res = ESP_FAIL;
        } else {
            _jpg_buf_len = fb->len;
            _jpg_buf = fb->buf;
        }
        if(res == ESP_OK){
            size_t hlen = snprintf((char *)part_buf, 64, _STREAM_PART, _jpg_buf_len);
            res = httpd_resp_send_chunk(req, (const char *)part_buf, hlen);
        }
        if(res == ESP_OK){
            res = httpd_resp_send_chunk(req, (const char *)_jpg_buf, _jpg_buf_len);
        }
        if(res == ESP_OK){
            res = httpd_resp_send_chunk(req, _STREAM_BOUNDARY, strlen(_STREAM_BOUNDARY));
        }
        if(fb){
            esp_camera_fb_return(fb);
            fb = NULL;
            _jpg_buf = NULL;
        } else if(_jpg_buf){
            free(_jpg_buf);
            _jpg_buf = NULL;
        }
        if(res != ESP_OK){
            break;
        }
    }
    return res;
}

void startCameraServer() {
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.ctrl_port = 32768;

    httpd_uri_t stream_uri = {
        .uri       = "/stream",
        .method    = HTTP_GET,
        .handler   = stream_handler,
        .user_ctx  = NULL
    };

    httpd_uri_t root_uri = {
        .uri       = "/",
        .method    = HTTP_GET,
        .handler   = stream_handler,
        .user_ctx  = NULL
    };

    Serial.printf("[HTTP] Iniciando servidor de vídeo en puerto %d...\n", config.server_port);
    if (httpd_start(&stream_httpd, &config) == ESP_OK) {
        httpd_register_uri_handler(stream_httpd, &stream_uri);
        httpd_register_uri_handler(stream_httpd, &root_uri);
        Serial.println("[HTTP] Servidor en puerto 80 activo (/stream y /)");
    }

    // Servidor secundario en puerto 81 por compatibilidad total
    httpd_config_t config81 = HTTPD_DEFAULT_CONFIG();
    config81.server_port = 81;
    config81.ctrl_port = 32769;

    httpd_uri_t stream_uri_81 = {
        .uri       = "/stream",
        .method    = HTTP_GET,
        .handler   = stream_handler,
        .user_ctx  = NULL
    };

    if (httpd_start(&stream_httpd_81, &config81) == ESP_OK) {
        httpd_register_uri_handler(stream_httpd_81, &stream_uri_81);
        Serial.println("[HTTP] Servidor en puerto 81 activo (/stream)");
    }
}

void setup() {
    Serial.begin(115200);
    Serial.setDebugOutput(true);
    Serial.println("\n\n--- INICIANDO PROMETHEUS ESP32-CAM SERVER ---");

    pinMode(FLASH_LED_PIN, OUTPUT);
    digitalWrite(FLASH_LED_PIN, LOW); // Flash apagado por defecto

    camera_config_t config;
    memset(&config, 0, sizeof(camera_config_t));

    Serial.printf("[MEMORIA] Heap libre: %d bytes | DMA libre: %d bytes | PSRAM: %d | PSRAM libre: %d bytes\n", 
        ESP.getFreeHeap(), 
        heap_caps_get_free_size(MALLOC_CAP_DMA), 
        psramFound(), 
        ESP.getFreePsram());

    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = Y2_GPIO_NUM;
    config.pin_d1 = Y3_GPIO_NUM;
    config.pin_d2 = Y4_GPIO_NUM;
    config.pin_d3 = Y5_GPIO_NUM;
    config.pin_d4 = Y6_GPIO_NUM;
    config.pin_d5 = Y7_GPIO_NUM;
    config.pin_d6 = Y8_GPIO_NUM;
    config.pin_d7 = Y9_GPIO_NUM;
    config.pin_xclk = XCLK_GPIO_NUM;
    config.pin_pclk = PCLK_GPIO_NUM;
    config.pin_vsync = VSYNC_GPIO_NUM;
    config.pin_href = HREF_GPIO_NUM;
    config.pin_sccb_sda = SIOD_GPIO_NUM;
    config.pin_sccb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn = PWDN_GPIO_NUM;
    config.pin_reset = RESET_GPIO_NUM;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_JPEG;

    // Optimización Ultra-Baja Latencia FPV (Resolución nativa OV2640 sin desbordamiento DMA)
    if(psramFound()){
        config.frame_size = FRAMESIZE_QVGA; // 320x240 nativo OV2640 (30-40 FPS, <20ms)
        config.jpeg_quality = 10;          // Calidad nítida
        config.fb_count = 1;               // 1 buffer para garantizar memoria DMA sobrante
        config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
        Serial.println("[CAM] Modo FPV Ultra-Rápido QVGA (320x240 @ 35 FPS)");
    } else {
        config.frame_size = FRAMESIZE_QVGA;
        config.jpeg_quality = 12;
        config.fb_count = 1;
        config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
        Serial.println("[CAM] Modo FPV Ligero QVGA (320x240)");
    }

    // Inicializar sensor de cámara OV2640
    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        Serial.printf("[ERROR] Fallo al inicializar sensor de cámara: 0x%x\n", err);
    } else {
        Serial.println("[CAM] Sensor OV2640 inicializado con éxito!");
    }

    sensor_t * s = esp_camera_sensor_get();
    if (s != NULL) {
        s->set_vflip(s, 1);    // Voltear vertical si hace falta según montaje
        s->set_hmirror(s, 0);  // Espejo desactivado
    }

    // Configurar Punto de Acceso Wi-Fi en Canal 1
    Serial.println("[WIFI] Configurando Punto de Acceso...");
    WiFi.mode(WIFI_AP);
    WiFi.softAPConfig(local_IP, gateway, subnet);
    WiFi.softAP(ssid, password, 1);

    Serial.println("[WIFI] Punto de Acceso emitido con éxito:");
    Serial.printf("       SSID: %s\n", ssid);
    Serial.printf("       PASS: %s\n", password);
    Serial.printf("       IP:   %s\n", WiFi.softAPIP().toString().c_str());

    // Iniciar servidores de vídeo MJPEG
    startCameraServer();

    Serial.println("\n>>> PROMETHEUS CAM LISTA Y TRANSMITIENDO <<<");
    Serial.println("Stream accesible en: http://192.168.4.1/stream");
    Serial.println("Y también en:       http://192.168.4.1:81/stream\n");
}

void loop() {
    // El servidor HTTP se gestiona por interrupciones en FreeRTOS
    delay(10000);
}
