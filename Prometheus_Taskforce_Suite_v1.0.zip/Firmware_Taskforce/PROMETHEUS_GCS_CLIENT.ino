/*
 * PROMETHEUS TASKFORCE — FIRMWARE RECEPTOR WI-FI UDP
 * Autor: Ernesto Torregrosa Palacio (Sparxx / FlameForge)
 * Grado en Ingenieria Mecanica — EPSA (UPV Campus d'Alcoi)
 * 
 * Descripcion:
 * Enlace unificado por antena Wi-Fi UDP (Latencia < 2 ms).
 * El ESP32 se conecta a la red Wi-Fi de la ESP32-CAM y recibe comandos
 * directamente desde la aplicacion C# 'Taskforce_GCS.exe' en tiempo real.
 * 
 * Mapeo de Pines (Hardware Validado Prometheus IV):
 * - Pin 16: Servo Direccion MG90S (Ackerman, 500-2400 us)
 * - Pin 26: Motor Izquierdo A (FWD)
 * - Pin 25: Motor Izquierdo A (BWD)
 * - Pin 18: Motor Derecho B (FWD)
 * - Pin 19: Motor Derecho B (BWD)
 * - Pin 15: Buzzer / Claxon
 * - Pin 2:  LED Indicador de Enlace Wi-Fi
 */

#include <WiFi.h>
#include <WiFiUdp.h>
#include <ESP32Servo.h>

// ====================================================================
// CONFIGURACION DE RED WI-FI (Ajustar al nombre de tu ESP32-CAM)
// ====================================================================
const char* WIFI_SSID     = "Prometheus_Wifi";  // Nombre exacto de la red Wi-Fi de la camara
const char* WIFI_PASSWORD = "Prometheus";         // Contrasena de la camara

const unsigned int UDP_PORT_RECV = 4210;       // Puerto donde escucha los mandos
const unsigned int UDP_PORT_TELE = 4211;       // Puerto donde envia telemetria

WiFiUDP udp;
Servo ServoSteering;

// === PINES ESP32 DEVKIT ===
const int pinLedConexion  = 2;
const int pinBuzzer       = 15;
const int pinServoSteer   = 16;

const int motorA_Fwd      = 26; // Izquierdo Adelante
const int motorA_Bwd      = 25; // Izquierdo Atras
const int motorB_Fwd      = 18; // Derecho Adelante
const int motorB_Bwd      = 19; // Derecho Atras

// === CALIBRACION DE DIRECCION ACKERMAN ===
const int STEERING_CENTER = 95;
const int STEERING_LEFT   = 46;
const int STEERING_RIGHT  = 146;

// === VARIABLES DE CONTROL ===
int currentPWM = 0;
char currentDirection = 'S'; // 'S' = Stop, 'F' = Fwd, 'B' = Bwd
int currentSteerAngle = 95;

unsigned long lastCommandTime = 0;
unsigned long lastTelemetryTime = 0;
const unsigned long FAILSAFE_TIMEOUT_MS = 500; // Parada automatica por seguridad

IPAddress remoteClientIP;
bool hasClient = false;

void setMotors(int fwdA, int bwdA, int fwdB, int bwdB) {
  analogWrite(motorA_Fwd, fwdA);
  analogWrite(motorA_Bwd, bwdA);
  analogWrite(motorB_Fwd, fwdB);
  analogWrite(motorB_Bwd, bwdB);
}

void stopMotors() {
  setMotors(0, 0, 0, 0);
  currentPWM = 0;
  currentDirection = 'S';
}

void setup() {
  Serial.begin(115200);

  pinMode(pinLedConexion, OUTPUT);
  pinMode(pinBuzzer, OUTPUT);
  pinMode(motorA_Fwd, OUTPUT);
  pinMode(motorA_Bwd, OUTPUT);
  pinMode(motorB_Fwd, OUTPUT);
  pinMode(motorB_Bwd, OUTPUT);

  // Asignar los 4 timers de hardware LEDC para evitar colision con los motores
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  ESP32PWM::allocateTimer(2);
  ESP32PWM::allocateTimer(3);

  // Inicializar servo de direccion con maxima fuerza de retencion
  ServoSteering.setPeriodHertz(50);
  ServoSteering.attach(pinServoSteer, 500, 2400);
  ServoSteering.write(STEERING_CENTER);

  stopMotors();

  // Conexion Wi-Fi en modo Cliente (busca en todos los canales)
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true);
  delay(100);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(200);
    digitalWrite(pinLedConexion, !digitalRead(pinLedConexion));
  }

  // Conexion Exitosa
  digitalWrite(pinLedConexion, HIGH);
  Serial.println("\n[PROMETHEUS] Conectado con exito a 'Prometheus - Wifi'");
  Serial.printf("[PROMETHEUS] IP del Coche: %s | Puerto: %d\n\n", WiFi.localIP().toString().c_str(), UDP_PORT_RECV);

  // Iniciar socket UDP
  udp.begin(UDP_PORT_RECV);

  // Pitido de exito
  digitalWrite(pinBuzzer, HIGH);
  delay(120);
  digitalWrite(pinBuzzer, LOW);
}

bool tankModeActive = false;

void applyDrive(bool forward, int basePWM) {
  if (basePWM <= 0) {
    stopMotors();
    return;
  }

  // Normalizar direccion de -1.0 (izq) a +1.0 (der). Centro 95.
  float normalizedSteer = (currentSteerAngle - 95.0f) / 50.0f;
  normalizedSteer = constrain(normalizedSteer, -1.0f, 1.0f);

  float diffAssist = 1.0f;
  if (abs(normalizedSteer) > 0.4f) diffAssist = 0.7f;
  if (abs(normalizedSteer) > 0.8f) diffAssist = 0.3f;

  int pwmA = basePWM;
  int pwmB = basePWM;

  if (normalizedSteer > 0.1f) pwmA = max(75, (int)(pwmA * diffAssist));
  if (normalizedSteer < -0.1f) pwmB = max(75, (int)(pwmB * diffAssist));

  if (forward) {
    int fwdA = pwmA, bwdA = 0;
    int fwdB = pwmB, bwdB = 0;

    // GIRO TANQUE SKID-STEER (Contrarotacion activa si el giro es > 85%)
    if (tankModeActive && normalizedSteer > 0.85f) {
      fwdA = 0;
      bwdA = max(75, (int)(basePWM * 0.4f));
    }
    if (tankModeActive && normalizedSteer < -0.85f) {
      fwdB = 0;
      bwdB = max(75, (int)(basePWM * 0.4f));
    }
    setMotors(fwdA, bwdA, fwdB, bwdB);
  } else {
    setMotors(0, pwmA, 0, pwmB);
  }
}

void parseCommand(const char* packet) {
  char cmd = toupper(packet[0]);
  int val = -1;

  if (strlen(packet) > 1) {
    val = atoi(&packet[1]);
  }

  lastCommandTime = millis();
  hasClient = true;

  switch (cmd) {
    case 'V': // Direccion Servo
      if (val > 180) { // Microsegundos (1000 a 2000 us)
        int us = constrain(val, 1000, 2000);
        currentSteerAngle = map(us, 1000, 2000, STEERING_LEFT, STEERING_RIGHT);
        ServoSteering.writeMicroseconds(us);
      } else if (val >= 0) { // Grados angulares (46° a 146°)
        currentSteerAngle = constrain(val, STEERING_LEFT, STEERING_RIGHT);
        int us = map(currentSteerAngle, STEERING_LEFT, STEERING_RIGHT, 1000, 2000);
        ServoSteering.writeMicroseconds(us);
      }
      // Si estamos en marcha, actualizar diferencial en tiempo real
      if (currentDirection == 'F') applyDrive(true, currentPWM);
      else if (currentDirection == 'B') applyDrive(false, currentPWM);
      break;

    case 'F': // Avance Adelante
      currentDirection = 'F';
      currentPWM = (val >= 0) ? constrain(val, 0, 255) : 140;
      applyDrive(true, currentPWM);
      break;

    case 'B': // Retroceso Atras
      currentDirection = 'B';
      currentPWM = (val >= 0) ? constrain(val, 0, 255) : 140;
      applyDrive(false, currentPWM);
      break;

    case 'K': // Toggle Modo Tanque (K1 = ON, K0 = OFF)
      tankModeActive = (val == 1);
      digitalWrite(pinBuzzer, HIGH);
      delay(40);
      digitalWrite(pinBuzzer, LOW);
      break;

    case 'S': // Parada suave
      stopMotors();
      break;

    case 'X': // Parada de emergencia instantanea
      stopMotors();
      digitalWrite(pinBuzzer, HIGH);
      delay(40);
      digitalWrite(pinBuzzer, LOW);
      break;

    case 'G': // Claxon / Bocina
      digitalWrite(pinBuzzer, HIGH);
      delay(120);
      digitalWrite(pinBuzzer, LOW);
      break;
  }
}

void loop() {
  // 1. Recibir paquetes UDP del mando (Cero Lag)
  int packetSize = udp.parsePacket();
  if (packetSize > 0) {
    char packetBuffer[64];
    int len = udp.read(packetBuffer, sizeof(packetBuffer) - 1);
    if (len > 0) {
      packetBuffer[len] = '\0';
      remoteClientIP = udp.remoteIP(); // Guardar IP del PC para enviarle telemetria
      hasClient = true;
      parseCommand(packetBuffer);
    }
  }

  // 2. Watchdog de Seguridad (Failsafe)
  // Si estamos en movimiento y no recibimos senal durante 500ms, frenar en seco
  if (currentDirection != 'S' && (millis() - lastCommandTime > FAILSAFE_TIMEOUT_MS)) {
    stopMotors();
  }

  // 3. Enviar Telemetria en tiempo real a la aplicacion (10-20 Hz)
  if (millis() - lastTelemetryTime > 80) {
    lastTelemetryTime = millis();
    char telemetry[64];
    // Formato: T,PWM,ANGULO,DIRECCION
    snprintf(telemetry, sizeof(telemetry), "T,%d,%d,%c", currentPWM, currentSteerAngle, currentDirection);
    
    if (hasClient) {
      udp.beginPacket(remoteClientIP, UDP_PORT_TELE);
      udp.write((const uint8_t*)telemetry, strlen(telemetry));
      udp.endPacket();
    } else {
      // Anunciar presencia a las posibles estaciones del AP para emparejar
      udp.beginPacket("192.168.4.2", UDP_PORT_TELE);
      udp.write((const uint8_t*)telemetry, strlen(telemetry));
      udp.endPacket();
      udp.beginPacket("192.168.4.3", UDP_PORT_TELE);
      udp.write((const uint8_t*)telemetry, strlen(telemetry));
      udp.endPacket();
      udp.beginPacket("192.168.4.255", UDP_PORT_TELE);
      udp.write((const uint8_t*)telemetry, strlen(telemetry));
      udp.endPacket();
    }
  }

  delay(2);
}
